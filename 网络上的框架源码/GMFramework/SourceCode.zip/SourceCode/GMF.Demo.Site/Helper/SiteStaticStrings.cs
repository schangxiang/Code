﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GMF.Demo.Site.Helper
{
    public class SiteStaticStrings
    {
        public const string LogCustomeMessage = "LOG_CUSTOM_MESSAGE";

        public const string LogOperationResult = "LOG_OPERATION_RESULT";
    }
}
