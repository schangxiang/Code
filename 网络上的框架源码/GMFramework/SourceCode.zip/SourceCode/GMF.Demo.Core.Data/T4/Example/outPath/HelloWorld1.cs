﻿using System;

namespace GMF.Demo.Core.Data.T4
{
    public class HelloWorld1
    {
        private string _word;

        public HelloWorld1(string word)
        {
            _word = word;
        }
    }
}
