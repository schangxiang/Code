﻿using System;

namespace GMF.Demo.Core.Data.T4
{
    public class HelloWorld2
    {
        private string _word;

        public HelloWorld2(string word)
        {
            _word = word;
        }
    }
}
